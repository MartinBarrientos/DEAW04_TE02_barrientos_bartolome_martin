<?php

namespace Kubio\Theme\Panels;


class AiOnboardingPanel extends \WP_Customize_Panel {

	public function render() {
		?>
		<div id="ai-onboarding-panel" class="ai-onboarding-panel">


		</div>
		<?php
	}



}
