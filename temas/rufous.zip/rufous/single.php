<?php get_header(); ?>
<?php rufous_theme()->get( 'single' )->render(); ?>
<?php
get_footer();
