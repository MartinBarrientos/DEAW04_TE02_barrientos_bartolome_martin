<?php

get_header();

rufous_theme()->get( 'main' )->render();

get_footer();
