<?php get_header(); ?>
<?php rufous_theme()->get( 'content' )->render(); ?>
<?php
get_footer();
