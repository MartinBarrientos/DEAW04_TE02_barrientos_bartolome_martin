<div class="wp-block wp-block-kubio-query-loop  position-relative wp-block-kubio-query-loop__container rufous-search__k__vrf0UGkWrN-container rufous-local-580-container gutters-row-lg-2 gutters-row-v-lg-2 gutters-row-md-2 gutters-row-v-md-2 gutters-row-0 gutters-row-v-2" data-kubio="kubio/query-loop" data-kubio-component="masonry" data-kubio-settings="{&quot;enabled&quot;:&quot;1&quot;,&quot;targetSelector&quot;:&quot;.wp-block-kubio-query-loop__inner&quot;}">
	<div class="position-relative wp-block-kubio-query-loop__inner rufous-search__k__vrf0UGkWrN-inner rufous-local-580-inner h-row">
		<?php rufous_theme()->get('archive-loop')->render(array (
  'view' => 'content/search/loop-item',
)); ?>
	</div>
</div>
