<li class="wp-block wp-block-kubio-iconlistitem  position-relative wp-block-kubio-iconlistitem__item rufous-header__k__jXl6zh8GbRi-item rufous-local-645-item" data-kubio="kubio/iconlistitem">
	<div class="position-relative wp-block-kubio-iconlistitem__text-wrapper rufous-header__k__jXl6zh8GbRi-text-wrapper rufous-local-645-text-wrapper">
		<span class="h-svg-icon wp-block-kubio-iconlistitem__icon rufous-header__k__jXl6zh8GbRi-icon rufous-local-645-icon" name="icons8-line-awesome/envelope-o">
			<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
		</span>
		<span class="position-relative wp-block-kubio-iconlistitem__text rufous-header__k__jXl6zh8GbRi-text rufous-local-645-text">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('text')); ?>
		</span>
	</div>
	<div class="last-el-spacer position-relative wp-block-kubio-iconlistitem__divider-wrapper rufous-header__k__jXl6zh8GbRi-divider-wrapper rufous-local-645-divider-wrapper"></div>
	<div class="position-relative wp-block-kubio-iconlistitem__divider-wrapper rufous-header__k__jXl6zh8GbRi-divider-wrapper rufous-local-645-divider-wrapper"></div>
</li>
