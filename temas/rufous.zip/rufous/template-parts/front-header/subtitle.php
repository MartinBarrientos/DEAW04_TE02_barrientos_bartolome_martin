<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<p class="wp-block wp-block-kubio-text  position-relative wp-block-kubio-text__text rufous-front-header__k__Xia0GT4t_-text rufous-local-166-text h-lead" data-kubio="kubio/text" id="paragraph-8">
	<?php $component->printSubtitle(); ?>
</p>
