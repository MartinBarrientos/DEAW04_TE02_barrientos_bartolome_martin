<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<figure class="wp-block wp-block-kubio-image  position-relative wp-block-kubio-image__outer rufous-front-header__k__ygm-Ztg031-outer rufous-local-174-outer size-large align-items-center" data-kubio="kubio/image">
	<div class="position-relative wp-block-kubio-image__captionContainer rufous-front-header__k__ygm-Ztg031-captionContainer rufous-local-174-captionContainer">
		<div class="position-relative wp-block-kubio-image__frameContainer rufous-front-header__k__ygm-Ztg031-frameContainer rufous-local-174-frameContainer">
			<?php $component->printImage(...array (
  0 => 'position-relative wp-block-kubio-image__image rufous-front-header__k__ygm-Ztg031-image rufous-local-174-image d-flex',
  1 => NULL,
)); ?>
<?php $component->printFrame('position-relative wp-block-kubio-image__frameImage'); ?>
		</div>
	</div>
</figure>
