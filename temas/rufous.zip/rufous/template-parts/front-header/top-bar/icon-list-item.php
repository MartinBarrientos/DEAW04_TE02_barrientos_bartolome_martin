<li class="wp-block wp-block-kubio-iconlistitem  position-relative wp-block-kubio-iconlistitem__item rufous-front-header__k__jcIWO_UNs6K-item rufous-local-134-item" data-kubio="kubio/iconlistitem">
	<div class="position-relative wp-block-kubio-iconlistitem__text-wrapper rufous-front-header__k__jcIWO_UNs6K-text-wrapper rufous-local-134-text-wrapper">
		<span class="h-svg-icon wp-block-kubio-iconlistitem__icon rufous-front-header__k__jcIWO_UNs6K-icon rufous-local-134-icon" name="icons8-line-awesome/envelope-o">
			<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
		</span>
		<span class="position-relative wp-block-kubio-iconlistitem__text rufous-front-header__k__jcIWO_UNs6K-text rufous-local-134-text">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('text')); ?>
		</span>
	</div>
	<div class="last-el-spacer position-relative wp-block-kubio-iconlistitem__divider-wrapper rufous-front-header__k__jcIWO_UNs6K-divider-wrapper rufous-local-134-divider-wrapper"></div>
	<div class="position-relative wp-block-kubio-iconlistitem__divider-wrapper rufous-front-header__k__jcIWO_UNs6K-divider-wrapper rufous-local-134-divider-wrapper"></div>
</li>
