<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<div class="wp-block wp-block-kubio-social-icons  position-relative wp-block-kubio-social-icons__outer rufous-front-header__k__yN8I0oN27tx-outer rufous-local-137-outer social-icons--container" data-kubio="kubio/social-icons">
	<?php $component->printIcons(); ?>
</div>
